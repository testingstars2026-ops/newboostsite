class Component {
problemData() {
return [
{ id: 'leads', label: 'Lead quality', question: 'Leads come in, but too few are worth a call', discipline: 'Performance media and analytics', title: 'Pay for enquiries that turn into revenue, not clicks.', body: 'We run Google Ads and Meta Ads against tracked calls and real revenue, never vanity clicks, with call tracking and attribution that survive contact with reality.', proof: '70% fewer wasted leads for a pain-management clinic, with 4× more leads a day.' },
{ id: 'website', label: 'Website conversion', question: 'Our website gets visits, not enquiries', discipline: 'High-converting websites', title: 'Rebuild the page around the one action that matters.', body: 'Landing pages, microsites and full websites built by the same team that markets them. Each page is designed to turn a visit into an enquiry, and measured so we can see whether it does.', proof: '' },
{ id: 'ai', label: 'AI visibility', question: 'Competitors show up in AI answers. We do not', discipline: 'AEO and GEO', title: 'Get retrieved and cited by the engines your customers now ask.', body: 'We audit where your brand appears in ChatGPT, Gemini, Perplexity and AI Overviews today, then engineer your content, entities and structured data so the engines cite you.', proof: '' },
{ id: 'local', label: 'Multi-location', question: 'Every location performs differently', discipline: 'Local and multi-location', title: 'Treat every branch as its own market.', body: 'Google Business Profiles, map-pack dominance, reviews and location launch playbooks, built for clinics, campuses and chains.', proof: '3× growth in new-patient bookings in 6 months for a multi-location veterinary group.' },
{ id: 'vendors', label: 'Too many vendors', question: 'Five vendors, and nobody owns growth', discipline: 'One growth system', title: 'One team, one system, one set of numbers.', body: 'Search feeds paid, paid feeds email, email feeds retention, and measurement maintains clarity. Every channel sounds like one brand, not five vendors.', proof: '95% client retention.' },
{ id: 'scratch', label: 'Building from scratch', question: 'We need to build digital revenue from nothing', discipline: 'Signature engagement', title: 'We build the whole engine, then hand you the keys.', body: 'Evaluate the potential, launch a lean first version, set strategy and pricing, scale what works, then hire and set up your in-house team to run it.', proof: 'Done end to end for a European media group.' }
];
}
current() {
return (this.state && this.state.problem) || 'leads';
}
componentDidMount() {
var self = this;
this._t = setInterval(function () { self.forceUpdate(); }, 20000);
this.startReveal();
this.startGlobe();
this.start90();
this.startTouches();
}
componentWillUnmount() {
clearInterval(this._t);
clearTimeout(this._rt);
if (this._io) this._io.disconnect();
if (this._raf) cancelAnimationFrame(this._raf);
if (this._raf90) cancelAnimationFrame(this._raf90);
}
startReveal() {
var root = this._root;
if (!root) return;
var els = root.querySelectorAll('.rv,.hl');
var still = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
var count = function (el) {
if (el._c || still) return; el._c = 1;
var node = el.firstChild; if (!node || node.nodeType !== 3) return;
var full = node.nodeValue, m = /^(\D*)([\d,]+(?:\.\d+)?)(.*)$/.exec(full); if (!m) return;
var target = parseFloat(m[2].replace(/,/g, '')), dec = (m[2].split('.')[1] || '').length, comma = m[2].indexOf(',') > -1, t0 = null;
var step = function (ts) {
if (t0 === null) t0 = ts;
var p = Math.min(1, (ts - t0) / 1500), v = target * (1 - Math.pow(1 - p, 3)), txt = v.toFixed(dec);
if (comma) txt = Math.round(v).toLocaleString('en-GB');
node.nodeValue = p < 1 ? m[1] + txt + m[3] : full;
if (p < 1) requestAnimationFrame(step);
};
requestAnimationFrame(step);
};
var show = function (el) { el.classList.add('in'); var cs = el.querySelectorAll('[data-count]'); for (var q = 0; q < cs.length; q++) count(cs[q]); };
root.classList.add('bx-js');
if (typeof IntersectionObserver === 'undefined') { els.forEach(show); return; }
var io = new IntersectionObserver(function (entries) {
entries.forEach(function (e) { if (e.isIntersecting) { show(e.target); io.unobserve(e.target); } });
}, { rootMargin: '0px 0px -8% 0px' });
els.forEach(function (el) { io.observe(el); });
this._io = io;
this._rt = setTimeout(function () {
var vh = window.innerHeight || 900;
els.forEach(function (el) { if (el.getBoundingClientRect().top < vh * 1.2) show(el); });
}, 1500);
}
startTouches() {
var root = this._root, self = this;
if (!root) return;
if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
var cur = null;
var rest = function (b) { if (b) { b.style.setProperty('--mx', '0px'); b.style.setProperty('--my', '0px'); } };
this._mm = function (e) {
var b = e.target && e.target.closest ? e.target.closest('.bx-btn') : null;
if (cur && cur !== b) rest(cur);
if (b) {
var r = b.getBoundingClientRect();
if (cur !== b) { b.style.setProperty('--fx', (e.clientX - r.left) + 'px'); b.style.setProperty('--fy', (e.clientY - r.top) + 'px'); }
b.style.setProperty('--mx', ((e.clientX - r.left - r.width / 2) * 0.16).toFixed(1) + 'px');
b.style.setProperty('--my', ((e.clientY - r.top - r.height / 2) * 0.3).toFixed(1) + 'px');
}
cur = b;
};
root.addEventListener('mousemove', this._mm);
root.addEventListener('mouseleave', function () { rest(cur); cur = null; });
}
start90() {
var path = this._p90, arrow = this._a90, self = this;
if (!path || !path.getTotalLength) return;
var L = path.getTotalLength();
var still = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
function place(t) {
var len = t * L, a = path.getPointAtLength(len), b = path.getPointAtLength(Math.min(L, len + 2));
path.setAttribute('stroke-dasharray', len + ' ' + (L + 20));
if (arrow) arrow.setAttribute('transform', 'translate(' + a.x + ' ' + a.y + ') rotate(' + (Math.atan2(b.y - a.y, b.x - a.x) * 180 / Math.PI) + ')');
}
if (still) { place(0.93); return; }
var t0 = null;
function frame(ts) {
if (t0 === null) t0 = ts;
var t = ((ts - t0) / 16000) % 1;
place(t);
var st = t < 0.07 ? 3 : t < 0.36 ? 0 : t < 0.57 ? 1 : t < 0.86 ? 2 : 3;
if (st !== self._s90) { self._s90 = st; self.setState({ step90: st }); }
self._raf90 = requestAnimationFrame(frame);
}
this._raf90 = requestAnimationFrame(frame);
}
startGlobe() {
var cv = this._globe;
if (!cv || !cv.getContext) return;
var ctx = cv.getContext('2d');
var self = this;
var D = Math.PI / 180;
var rot = 62, tilt = 16, dragging = false, lx = 0, ly = 0, idle = 0;
var still = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
var cities = [
{ n: 'New York', lat: 40.7, lon: -74.0, dy: -16 },
{ n: 'Washington DC', lat: 38.9, lon: -77.0, dy: 30 },
{ n: 'London', lat: 51.5, lon: -0.1, dy: -16 },
{ n: 'Dubai', lat: 25.2, lon: 55.3, dy: 30 },
{ n: 'Delhi', lat: 28.6, lon: 77.2, dy: -18, hq: true },
{ n: 'Singapore', lat: 1.35, lon: 103.8, dy: 30 },
{ n: 'Hong Kong', lat: 22.3, lon: 114.2, dy: -16 }
];
var W = 840, C = W / 2, R = 330;
function proj(lat, lon) {
var p = lat * D, l = (lon - rot) * D, t = tilt * D;
var x = Math.cos(p) * Math.sin(l), y = Math.sin(p), z = Math.cos(p) * Math.cos(l);
var y2 = y * Math.cos(t) - z * Math.sin(t), z2 = y * Math.sin(t) + z * Math.cos(t);
return [C + x * R, C - y2 * R, z2];
}
function vec(lat, lon) { var p = lat * D, l = lon * D; return [Math.cos(p) * Math.cos(l), Math.cos(p) * Math.sin(l), Math.sin(p)]; }
function arc(a, b) {
var va = vec(a.lat, a.lon), vb = vec(b.lat, b.lon);
var dot = va[0] * vb[0] + va[1] * vb[1] + va[2] * vb[2];
var om = Math.acos(Math.max(-1, Math.min(1, dot))), pts = [];
for (var i = 0; i <= 48; i++) {
var f = i / 48, s1 = Math.sin((1 - f) * om) / Math.sin(om), s2 = Math.sin(f * om) / Math.sin(om);
var x = s1 * va[0] + s2 * vb[0], y = s1 * va[1] + s2 * vb[1], z = s1 * va[2] + s2 * vb[2];
pts.push([Math.asin(z) / D, Math.atan2(y, x) / D]);
}
return pts;
}
var hq = cities[4];
var arcs = cities.filter(function (c) { return !c.hq; }).map(function (c) { return arc(hq, c); });
var grid = [];
for (var la = -84; la <= 84; la += 6) {
var n = Math.max(6, Math.round(60 * Math.cos(la * D)));
for (var k = 0; k < n; k++) grid.push([la, (k / n) * 360 - 180 + (la % 12 === 0 ? 0 : 180 / n)]);
}
function draw(ts) {
var accent = self.props.accent || '#9BE8C4';
ctx.clearRect(0, 0, W, W);
ctx.beginPath(); ctx.arc(C, C, R + 14, 0, 7); ctx.strokeStyle = '#3A4640'; ctx.lineWidth = 2; ctx.stroke();
ctx.beginPath(); ctx.arc(C, C, R, 0, 7); ctx.fillStyle = '#121B17'; ctx.fill();
var i, p;
for (i = 0; i < grid.length; i++) {
p = proj(grid[i][0], grid[i][1]);
if (p[2] <= 0) continue;
ctx.globalAlpha = 0.18 + 0.6 * p[2];
ctx.beginPath(); ctx.arc(p[0], p[1], 1.6 + 2.2 * p[2], 0, 7); ctx.fillStyle = '#7C8A83'; ctx.fill();
}
ctx.globalAlpha = 1;
ctx.lineWidth = 3; ctx.strokeStyle = accent; ctx.setLineDash([10, 9]); ctx.lineDashOffset = -(ts || 0) / 45;
for (i = 0; i < arcs.length; i++) {
ctx.beginPath(); var pen = false;
for (var j = 0; j < arcs[i].length; j++) {
p = proj(arcs[i][j][0], arcs[i][j][1]);
if (p[2] > 0.02) { if (pen) ctx.lineTo(p[0], p[1]); else ctx.moveTo(p[0], p[1]); pen = true; } else pen = false;
}
ctx.stroke();
}
ctx.setLineDash([]);
ctx.font = '500 24px "Inter Tight", Arial, sans-serif'; ctx.textAlign = 'center';
for (i = 0; i < cities.length; i++) {
var c = cities[i]; p = proj(c.lat, c.lon);
if (p[2] <= 0.05) continue;
var pulse = c.hq ? 6 * (0.5 + 0.5 * Math.sin((ts || 0) / 500)) : 0;
if (c.hq) { ctx.beginPath(); ctx.arc(p[0], p[1], 20 + pulse, 0, 7); ctx.strokeStyle = accent; ctx.lineWidth = 2; ctx.stroke(); }
ctx.beginPath(); ctx.arc(p[0], p[1], c.hq ? 11 : 8, 0, 7); ctx.fillStyle = c.hq ? accent : '#F2F3F0'; ctx.fill();
var label = c.hq ? 'Delhi · HQ' : c.n, tw = ctx.measureText(label).width, ty = p[1] + c.dy + (c.dy < 0 ? -12 : 12);
ctx.fillStyle = '#0E1512'; ctx.fillRect(p[0] - tw / 2 - 8, ty - 22, tw + 16, 30);
ctx.fillStyle = '#F2F3F0'; ctx.fillText(label, p[0], ty);
}
}
function frame(ts) {
if (!dragging && !still) { if (idle > 0) idle--; else rot += 0.12; }
draw(ts);
self._raf = requestAnimationFrame(frame);
}
cv.addEventListener('pointerdown', function (e) { dragging = true; lx = e.clientX; ly = e.clientY; cv.style.cursor = 'grabbing'; if (cv.setPointerCapture) cv.setPointerCapture(e.pointerId); });
cv.addEventListener('pointermove', function (e) {
if (!dragging) return;
rot -= (e.clientX - lx) * 0.35; tilt = Math.max(-35, Math.min(55, tilt + (e.clientY - ly) * 0.25));
lx = e.clientX; ly = e.clientY;
});
var end = function () { dragging = false; idle = 120; cv.style.cursor = 'grab'; };
cv.addEventListener('pointerup', end);
cv.addEventListener('pointercancel', end);
this._raf = requestAnimationFrame(frame);
}
clock(tz) {
var time = '--:--';
var hour = 12;
try {
time = new Intl.DateTimeFormat('en-GB', { hour: '2-digit', minute: '2-digit', hour12: false, timeZone: tz }).format(new Date());
hour = parseInt(time.slice(0, 2), 10);
} catch (e) {}
var online = hour >= 8 && hour < 22;
return { time: time, status: online ? 'Online' : 'Resting', dot: online ? '#9BE8C4' : 'transparent' };
}
renderVals() {
var self = this;
var cur = this.current();
var data = this.problemData();
var accent = this.props.accent ?? '#9BE8C4';
if (!this._setRoot) this._setRoot = function (el) { if (el) self._root = el; };
if (!this._setGlobe) this._setGlobe = function (el) { if (el) self._globe = el; };
if (!this._setP90) this._setP90 = function (el) { if (el) self._p90 = el; };
if (!this._setA90) this._setA90 = function (el) { if (el) self._a90 = el; };
var s90 = (this.state && typeof this.state.step90 === 'number') ? this.state.step90 : -1;
var p90 = {};
['a', 'b', 'c', 'd'].forEach(function (k, i) { var on = s90 === -1 || s90 === i; p90[k] = { fill: on && s90 !== -1 ? accent : '#F2F3F0', rule: on ? accent : '#5C9485', op: '1' }; });
var sel = data[0];
var problems = data.map(function (d) {
var on = d.id === cur;
if (on) sel = d;
return { question: d.question, pressed: on ? 'true' : 'false', bg: on ? accent : 'transparent', fg: on ? '#0E1512' : '#F2F3F0', pick: function () { self.setState({ problem: d.id }); } };
});
var chips = data.concat([{ id: 'other', label: 'Something else' }]).map(function (d) {
var on = d.id === cur;
return { label: d.label, pressed: on ? 'true' : 'false', bg: on ? '#0E1512' : 'transparent', fg: on ? '#F2F3F0' : '#0E1512', pick: function () { self.setState({ problem: d.id }); } };
});
if (this._introCls === undefined) { var seen = false; try { seen = !!window.sessionStorage.getItem('bxIntro'); window.sessionStorage.setItem('bxIntro', '1'); } catch (e) {} this._introCls = seen ? '' : 'bx-intro-play'; }
var sent = !!(this.state && this.state.sent);
return {
accent: accent,
introCls: this._introCls,
setRoot: this._setRoot,
setGlobe: this._setGlobe,
setP90: this._setP90,
setA90: this._setA90,
p90: p90,
problems: problems,
chips: chips,
sel: { discipline: sel.discipline, title: sel.title, body: sel.body, proof: sel.proof, hasProof: !!sel.proof },
sent: sent,
notSent: !sent,
submit: function (e) { if (e && e.preventDefault) e.preventDefault(); self.setState({ sent: true }); },
reset: function () { self.setState({ sent: false }); },
delhi: this.clock('Asia/Kolkata'),
newyork: this.clock('America/New_York'),
singapore: this.clock('Asia/Singapore')
};
}
}

(function () {
var A = '#9BE8C4';
var c = new Component();
c.props = { accent: A };
c.state = {};
c._root = document.getElementById('bx-root');
c._globe = document.getElementById('bx-globe');
c._p90 = document.getElementById('bx-p90');
c._a90 = document.getElementById('bx-a90');
var data = c.problemData(), chips = data.concat([{ id: 'other', label: 'Something else' }]);
function each(sel, fn) { var l = document.querySelectorAll(sel); for (var i = 0; i < l.length; i++) fn(l[i]); }
function clocks() {
each('[data-tz]', function (el) {
var k = c.clock(el.getAttribute('data-tz')), f = el.getAttribute('data-f');
if (f === 'time') el.textContent = k.time; else if (f === 'status') el.textContent = k.status; else el.style.background = k.dot;
});
}
function step(s) {
['a', 'b', 'c', 'd'].forEach(function (k, i) {
var on = s === -1 || s === i;
each('[data-p90="' + k + '"]', function (el) {
if (el.tagName.toLowerCase() === 'circle') el.setAttribute('fill', on && s !== -1 ? A : '#F2F3F0');
else { el.style.borderTopColor = on ? A : '#5C9485'; el.style.opacity = '1'; }
});
});
}
function pick(id) {
var d = null;
data.forEach(function (x) { if (x.id === id) d = x; });
each('[data-problem]', function (b) {
var on = b.getAttribute('data-problem') === id;
b.setAttribute('aria-pressed', on ? 'true' : 'false');
b.style.background = on ? A : 'transparent';
b.style.color = on ? '#0E1512' : '#F2F3F0';
});
each('[data-chip]', function (b) {
var on = b.getAttribute('data-chip') === id;
b.setAttribute('aria-pressed', on ? 'true' : 'false');
b.style.background = on ? '#0E1512' : 'transparent';
b.style.color = on ? '#F2F3F0' : '#0E1512';
});
var label = 'Something else';
chips.forEach(function (x) { if (x.id === id) label = x.label; });
each('input[name="problem"]', function (i) { i.value = label; });
if (d) {
each('[data-sel]', function (el) { el.textContent = d[el.getAttribute('data-sel')] || ''; });
each('[data-if="proof"]', function (el) { el.hidden = !d.proof; });
each('.bx-answer', function (el) { el.classList.remove('bx-swap'); void el.offsetWidth; el.classList.add('bx-swap'); });
}
}
c.forceUpdate = clocks;
c.setState = function (o) {
for (var k in o) c.state[k] = o[k];
if ('step90' in o) step(o.step90);
if ('problem' in o) pick(o.problem);
};
each('[data-problem]', function (b) { b.addEventListener('click', function () {
c.setState({ problem: b.getAttribute('data-problem') });
var ans = document.querySelector('.bx-answer');
if (ans && window.innerWidth < 900) { var r = ans.getBoundingClientRect(); if (r.top > window.innerHeight - 120 || r.bottom < 80) ans.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
}); });
each('[data-chip]', function (b) { b.addEventListener('click', function () { c.setState({ problem: b.getAttribute('data-chip') }); }); });
each('form[data-netlify]', function (f) {
var box = f.closest('.bx-formbox');
f.addEventListener('submit', function (e) {
e.preventDefault();
var err = box.querySelector('.bx-err'), btn = f.querySelector('button[type="submit"]');
err.hidden = true; btn.disabled = true;
fetch('/', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams(new FormData(f)).toString() })
.then(function (r) {
if (!r.ok) throw new Error(r.status);
box.querySelector('[data-if="notSent"]').hidden = true;
box.querySelector('[data-if="sent"]').hidden = false;
f.reset(); pick(c.state.problem || 'leads');
})
.catch(function () { err.hidden = false; })
.then(function () { btn.disabled = false; });
});
var again = box.querySelector('[data-action="reset"]');
if (again) again.addEventListener('click', function () {
box.querySelector('[data-if="notSent"]').hidden = false;
box.querySelector('[data-if="sent"]').hidden = true;
});
});
each('.bx-menu-btn', function (b) {
var nav = document.getElementById('bx-mnav');
b.addEventListener('click', function () { var open = nav.hidden; nav.hidden = !open; b.setAttribute('aria-expanded', open ? 'true' : 'false'); });
each('#bx-mnav a', function (a) { a.addEventListener('click', function () { nav.hidden = true; b.setAttribute('aria-expanded', 'false'); }); });
});
clocks();
setInterval(clocks, 20000);
c.startReveal();
c.startGlobe();
c.start90();
c.startTouches();
})();
